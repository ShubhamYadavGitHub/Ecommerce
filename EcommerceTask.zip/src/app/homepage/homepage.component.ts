import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {
  cart_qty: any;
  total_product: any = 0;
  totalProducts: any = 0;
  add!: boolean;
  productList = [
    { name: 'Samsung M 20', price: 99 },
    { name: 'Samsung M 30', price: 109 },
    { name: 'Samsung M 21', price: 156 },
    { name: 'Samsung M 80S', price: 1000 },
    { name: 'Samsung M 60S', price: 1100 },
    { name: 'Samsung M 10', price: 260 }
  ];

  getProduct: any = []; getTotalProduct: any = '0';
  constructor() {
    this.getProduct = localStorage.getItem('PRODUCTS');
    this.getTotalProduct = localStorage.getItem('TotalProducts');

    console.log(this.getProduct);
    console.log(this.getTotalProduct)
    if (this.getTotalProduct == null) {
      this.totalProducts = 0;
    }
    else {
      this.totalProducts = parseInt(this.getTotalProduct);
    }
    // localStorage.getItem('dataSource'); 
  }

  ngOnInit(): void {
  }
  obj: any = {}
  arr: any;
  productName: any;
  onAdd(product: any) {
    this.totalProducts += 1;
    console.log(this.totalProducts)
    const productExistInCart = this.cartProductList.find((value: any) => value.name === product.name); // find product by name
    if (!productExistInCart) {
      this.cartProductList.push({ ...product, num: 1 });
      console.log(this.cartProductList); // enhance "product" object with "num" property
      return;
    }
    productExistInCart.num += 1;
    console.log(this.cartProductList);
  } comp: any = []; cartProductList: any = []; onSub(product: any) {
    if (this.totalProducts > 0) {
      this.totalProducts -= 1;
    }
    this.add = false;
    const productExistInCart1: any = this.cartProductList.find((value: any) => value.name === product.name); // find product by name
    console.log(productExistInCart1)
    if (productExistInCart1) {
      productExistInCart1.num -= 1;
      console.log(productExistInCart1.num)
      if (productExistInCart1.num === 0) {
        this.cartProductList.splice(this.cartProductList.findIndex(this.data), 1)
      }
      console.log(this.cartProductList); // enhance "porduct" opject with "num" property
      return;
    }
    console.log(this.cartProductList);
  }
  data(el: any) {
    return el.num === 0;
  }
  addCart() {
    // this.total_product.loc
  }


  x() {

    console.log(this.cartProductList);
    // this.cartProductList.push({totalProduct:this.totalProducts})
    localStorage.setItem('PRODUCTS', JSON.stringify(this.cartProductList));
    localStorage.setItem('TotalProducts', JSON.stringify(this.totalProducts));

  }

}
